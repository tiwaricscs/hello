<?php
session_start();
if (!$_SESSION['email']) {
	header("location:index.php");
}
$conn=mysqli_connect("localhost","root","","form");


?>
<?php
 if (isset($_POST['delete'])) {
  $id=$_POST['id'];
  $sql = "UPDATE `email_table` SET `sent_delete`=1 where `id`='$id'";
  $qry=mysqli_query($conn,$sql);
  if ($qry) {
  	 echo '<script>alert("delete success");</script>';
  }
 }
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<a href="email.php"><button>Back</button></a>
	<h2 ><u>Sent Box</u></h2>
      <table border="1">
  	   	<tr>
  	   		<th>sender_email</th>
  	   		<th>receiver_email</th>
  	   		<th>subject</th>
  	   		<th>message</th>
  	   		<th>delete</th>
  	   	</tr>
   <?php
   $sql="SELECT * FROM `email_table` WHERE `sender_email`='$_SESSION[email]' AND `sent_delete`=0";
$qry=mysqli_query($conn,$sql);
while ($data=mysqli_fetch_array($qry)) {?>
	<tr>
		<td><?=$data['sender_email']?></td>
		<td><?=$data['receiver_email']?></td>
		<td><?=$data['subject']?></td>
		<td><?=$data['message']?></td>
		<td>
			<form method="post">
				<input type="hidden" name="id" value="<?=$data['id']?>">
				<input type="submit" name="delete" value="delete">
			</form>
		</td>
	</tr>
<?php }
   ?>
  	   </table>

  
</body>
</html>