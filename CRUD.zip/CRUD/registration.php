<?php
session_start();
 if (!isset($_POST['hid']) || $_POST['hid'] !='1') {
   
    $captcha_generator = md5( rand());   
    $_SESSION['captcha'] = substr($captcha_generator , 0 , 6);
  }

$alert="";
$unique="";

$firstnameErr=$emailErr=$mobileErr=$ageErr=$dobErr=$genderErr=$educationErr=$captchaErr=$passwordErr=$colorErr=$sportErr='';
$firstname=$email=$mobile=$age=$dob=$gender=$edu=$color=$sport='';

$conn=mysqli_connect("localhost","root","","form");
       
if (isset($_POST['submit'])) {
          extract($_POST);
          //$n6=date("y/m/d");
          $error=false;
                    if ($_POST['captcha'] !=  $_SESSION['captcha']) {
                          $captchaErr="Captcha does not match";
                            $error=true;
                        
                      }
                      else{

                        }
                     if (empty($n1)) {
                     $firstnameErr="Enter firstname";
                     $error=true;
                     } 
                     else{
                         $firstname=$_POST['n1'];
                          if (!preg_match("/^[a-zA-Z ]*$/",$firstname)) {
                          $firstnameErr = "Only letters and white space allowed";
                        }
                     }

                     if (empty($n3)) {
                  $emailErr="Enter email address";
                  $error=true;
                     } 
                     else{
                  $email=$_POST['n3'];
                  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                       $emailErr = "Invalid email format";
                     }
                     }

                     if (empty($n4)) {
                  $mobileErr="Enter mobile number";
                  $error=true;
                     } 
                     else{
                         $mobile=$_POST['n4'];
                     }

                     if (empty($n5)) {
                  $ageErr="Enter your age";
                  $error=true;
                     } 
                     else{
                         $age=$_POST['n5'];
                     }

                     if (empty($n6)) {
                  $dobErr="Enter your date of birth";
                  $error=true;
                     } 
                     else{
                         $dob=$_POST['n6'];
                     }

                     if (empty($n7)) {
                  $genderErr="Enter your gender";
                  $error=true;
                     } 
                     else{
                         $gender=$_POST['n7'];
                     }  
                      if (empty($password)) {
                  $passwordErr="kindly Enter password";
                  $error=true;
                     } 
                     else{
                         $password=$_POST['password'];
                     }
                         if (empty($color)) {
                  $colordErr="kindly Enter your favourite color";
                  $error=true;
                     } 
                     else{
                         $color=$_POST['color'];
                     }
                         if (empty($sport)) {
                  $sportErr="kindly Enter your favourite sport";
                  $error=true;
                     } 
                     else{
                         $sport=$_POST['sport'];
                     }
                     if (empty($edu_from)||empty($edu_to)||empty($edu_course)||empty($edu_college)) {
                    $educationErr="Enter your qualification";
                     $error=true;
                     } 
                     else{
                  
     
          $education=array("from"=>$_POST['edu_from'],
                          "to"=>$_POST['edu_to'],
                          "course"=>$_POST['edu_course'],
                          "college"=>$_POST['edu_college']
                     
                     );

          $edu=json_encode($education);
        
     }

                               
      if ($error==false) {
      if (!empty($accept)) {      
      
     $file=$_FILES['file'];
     $fname=$file['name'];
     $tname=$file['tmp_name'];
     $fn=date('d_m_y_h_i_s').$fname;

     
     

     if ($file['type']=="image/jpg" || $file['type']=="image/jpeg" || $file['type']=="image/png") {
          
     if ($file['size']<(1024*1024)) {
      move_uploaded_file($tname, "img/$fn");
     $role = 2 ;
     $sql="INSERT INTO `desc`(`role`,`firstname`, `lastname`, `email`, `mobile`,`experience`, `age`, `dob`, `education`, `gender`, `address`, `image`,`password`,`favourite_color`,`favourite_sport`) VALUES (2,'$n1','$n2','$n3','$n4','$exp','$n5','$n6','$edu','$n7','$n8','$fn','$password','$color','$sport')";
      
	$qry=mysqli_query($conn,$sql);
		if ($qry) {
			  
                $alert=true;
			}	
			else{
				echo mysqli_error($conn);
        $unique=true;
			}
		}
          else{
               echo "file size limit exceeds";
          }
	}

     else{
         $sql="INSERT INTO `desc`(`role`,`firstname`, `lastname`, `email`, `mobile`,`experience`, `age`, `dob`, `education`, `gender`, `address`,`password`,`favourite_color`,`favourite_sport`) VALUES (2,'$n1','$n2','$n3','$n4','$exp','$n5','$n6','$edu','$n7','$n8','$password','$color','$sport')";
          
          $qry=mysqli_query($conn,$sql);
          if ($qry) {
               
               $alert=true;
               }    
               else{
                    echo mysqli_error($conn);
                    $unique=true;
               } 
     }
 }
 else{
      
     echo '<script>alert("kindly accept the terms and conditions");</script>';
 }
}
}

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
     <style>
          *{
      margin: 0px;
      padding: 0px;
    }
  ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
  position: sticky;
  top: 0;
}

li {
  float: left;
  
  display: block;
  color: orange;
  text-align: center;
  padding: 14px ;
  font-size: 32px;
  text-decoration: none;
  margin-left: 50px;

}

ul li :hover {
  background-color: black;
}
          .acc{
               color: green;
          }
          .err{
               color: red;
               font-size: 20px;
          }
           
     </style>    
     <script type="text/javascript" src="js/jquery-3.5.1.min.js"></script>
     <script>
       $(document).ready(function() {
      $("#btn").click(function(){
      
       var a=$(".row").html();
       $(".row").after(a);

       
       return false;
    });
  });
     </script>
</head>
<body>
  <ul>
      <li><b><u><em>BALLISTIC LEARNING PVT LTD</em></u></b></li>
   
     </ul>
     <br><br>
	<h2><u> REGISTRATION - FORM</u></h2><br>
  <?php
  if ($alert) { ?>
    <h3 style="color:green;padding: 1px;font-size: 32px;"><b><u>Success:your credentials are inserted successfully</u></b></h3>
 <?php }
  ?>

  <?php
  if ($unique) {?>
      <h3 style="color: red;font-size: 32px;"><b><u>Email is already registered</u></b></h3>
 <?php }
  ?>
    <form method="post" enctype="multipart/form-data">  
          
     	<table>
     		<tr>
     			<td><b>Firstname:</b></td>
     		<td><input type="text" name="n1" placeholder="Enter firstname"  value="<?php echo $firstname;?>">
                    <span class="err">*<?php echo $firstnameErr;?></span></td>
     		</tr>
     		<tr>
     			<td><b>Lastname:</b></td>
     			<td><input type="text" name="n2" placeholder="Enter lastname"></td>
     		</tr>
     		<tr>
     			<td><b>Email:</b></td>
     			<td><input type="email" name="n3" placeholder="Enter email address" value="<?php echo $email;?>">
                         <span class="err">*<?php echo $emailErr;?></span></td>
     		</tr>
     			<tr>
     			  <td><b>Mobile:</b></td>
     			<td><input type="number" name="n4" placeholder="Enter Mobile number" value="<?php echo $mobile;?>">
                         <span class="err">*<?php echo $mobileErr;?></span></td>
     		</tr>
               <tr>
                    <td><b>Experience:</b></td>
                    <td>
                         <select name="exp" >
                              <option>fresher</option>
                              <option>trainee</option>
                              <option>experienced</option>
                         </select>
                    </td>
               </tr>
     			<tr>
     			<td><b>Age:</b></td>
     			<td><input type="number" min="18" max="58" name="n5">
                         <span class="err">*<?php echo $ageErr;?></span></td>
     		</tr>
     			<tr>
     			<td><b>D.O.B:</b></td>
     			<td><input type="date" name="n6">
                         <span class="err">*<?php echo $dobErr;?></span></td>
     		</tr>
     		<tr class="row">
     			<td>
            <b>Education:</b></td>
                <td id="edu_repeat">
            <small><b>from</b></small>
     				<input type="date" name="edu_from[]">
     				<small><b>to</b></small>
     				<input type="date" name="edu_to[]">
     				 <small><b>course</b></small>
     				<input type="text" name="edu_course[]" placeholder="Enter college name">
     			  <small><b>college</b></small>
     				<input type="text" name="edu_college[]" placeholder="Enter course"> 
     				
     			<span class="err">*<?php echo $educationErr;?></span></td>
          
     		</tr>
        <tr>
          <td><input type="submit" name="" id="btn"  value="Add Education"> </td>
        </tr>
     		<tr>
     			<td><b>Gender:</b></td>
     			<td><input type="radio" name="n7" value="male">male
     			<input type="radio" name="n7" value="female">female
     			<input type="radio" name="n7" value="other">other
                    <span class="err">*<?php echo $genderErr;?></span></td>
     		</tr>
     		<tr>
     			<td><b>Address:</b></td>
     			<td><textarea rows="5" cols="40" name="n8" placeholder="Enter address"></textarea></td>
     		</tr>
     		
     		<tr>
     			<td><b>Image</b></td>
     			<td><input type="file" name="file"></td>
     		</tr>
        <tr>
          <td><b>Password</b></td>
          <td><input type="password" name="password">
            <span class="err">*<?php echo $passwordErr;?></span></td>
        </tr>
               <tr>
                    <td>captcha</td>
                     <td><?php echo $_SESSION['captcha'];?></td> 
                     </tr>
                     <tr>
                         <td></td>
                  <td>
                    <input type="hidden" name="hid" value="1">
                    <input type="captcha" name="captcha" placeholder="Enter captcha text">
                    <span class="err">*<?php echo $captchaErr;?></span></td>
               </tr>     
               <tr>
                 <td><b> What is favourite color ?</b></td>
                 <td><input type="radio" name="color" value="blue">Blue
                 <input type="radio" name="color" value="green">Green
                 <input type="radio" name="color" value="red">Red
                 <input type="radio" name="color" value="orange">Orange
               <span class="err">*<?php echo $colorErr;?></span></td>
               </tr> 
                 <tr>
                 <td><b> Which is your favourite sport ?</b></td>
                 <td><input type="radio" name="sport" value="basketball">Basketball
                 <input type="radio" name="sport" value="cricket">Cricket
                 <input type="radio" name="sport" value="tennis">Tennis
                 <input type="radio" name="sport" value="football">Football
               <span class="err">*<?php echo $sportErr;?></span></td>
               </tr> 
     		<tr>
     			<td></td>
     			<td><input type="checkbox" name="accept" value="1"><b>I agree to the terms and conditions</b></td>
     		</tr>
          <tr>
            <td></td>
          <td><a href="login.php"><b><u>Already have an Account</u></b></a></td>
        </tr>
     		<tr>
     			<td><input type="reset" name="reset"></td>
     			<td><input type="submit" name="submit"></td>

     		</tr>
     	</table>
     </form>
      
</body>
</html>
 
