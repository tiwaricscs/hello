<?php
session_start();
$conn=mysqli_connect("localhost","root","","form");
if (isset($_GET['submit'])) {
	extract($_GET);
	$email=$_GET['email'];
	$_SESSION['email']=$_GET['email'];
	$sql="SELECT * FROM `desc`WHERE `email`='$email'";
	$qry=mysqli_query($conn,$sql);
	if ($qry) {
		$data=mysqli_fetch_array($qry);
	if ($_GET['email']==$data['email'] && $_GET['color']==$data['favourite_color'] && $_GET['sport']==$data['favourite_sport']) {
		 	 header('location:new_password.php');
		 }
		 else{
		 	echo '<script> alert("credentials did not match");</script>';
		 }
	}
}

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
 		*{
 			margin: 0px;
 			padding: 0px;
 		}
  ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
  position: sticky;
  top: 0;
}

li {
  float: left;
  
  display: block;
  color: orange;
  text-align: center;
  padding: 14px ;
  font-size: 32px;
  text-decoration: none;
  margin-left: 50px;

}

ul li :hover {
  background-color: black;
}
.err{
	color: red;
}

 </style>
</head>
<body>
    <ul>
     	<li><b><u><em>BALLISTIC LEARNING PVT LTD</em></u></b></li>
   
     </ul><br><br>
  <h1><u>In order to retrieve your password kindly answer the following question</u></h1><br><br>
  <form method="get">
  <h3>1. What is favourite color ?</h3><br> 
     <b> a).Blue   <input type="radio" name="color" value="blue">
      b). Green  <input type="radio" name="color" value="green">
      c).  Red  <input type="radio" name="color" value="red">
      d). Orange  <input type="radio" name="color" value="orange"></b>
      <br><br><br>

       <h3>2. Which is favourite sport ?</h3><br> 
     <b> a). Basketball  <input type="radio" name="sport" value="basketball">
      b). Cricket  <input type="radio" name="sport" value="cricket">
      c). Tennis  <input type="radio" name="sport" value="tennis">
      d). Football  <input type="radio" name="sport" value="football"></b>
      <br><br>

      <h3>3. Enter your email address: <input type="email" name="email"> </h3><br> 

         <input type="submit" name="submit" value="Submit" style="font-size: 24px;">
  </form>
</body>
</htsport