 <!DOCTYPE html>
 <html>
 <head>
 	<title>crud project</title>
 	<style type="text/css">
 		*{
 			margin: 0px;
 			padding: 0px;
      
 		}
  ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
  position: sticky;
  top: 0;
}

li {
  float: left;
  
  display: block;
  color: orange;
  text-align: center;
  padding: 14px ;
  font-size: 32px;
  text-decoration: none;
  margin-left: 50px;

}

ul li :hover {
  background-color: black;
}
.btn1{
	padding: 15px;
	font-weight: bold;
	margin-top: 300px;
	background-color: lightblue;
	color: #000;
  margin-left: 550px;
    }
.btn2{
	padding: 15px;
	font-weight: bold;
	margin-top: 300px;
	background-color: lightblue;
	color: #000;

    }
.p{
	color: #fff;
	font-weight: bold;
	font-size: 24px;
	text-align: center;
}
 </style>
 </head>
 <body>
     <ul>
     	<li><b><u><em>BALLISTIC LEARNING PVT LTD</em></u></b></li>
   
     </ul>
     <img src="img/pic1.jpg" style="width: 100%;height: 800px;position: absolute;z-index: -1;">
    <a href="registration.php"> <button class="btn1">Register</button></a>
     <a href="login.php"><button class="btn2">Login</button></a><br><br>

     <p class="p">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
     tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
     quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
     consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
     cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
     proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
     <p class="p">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
     tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
     quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
     consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
     cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
     proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
</body>
</html>