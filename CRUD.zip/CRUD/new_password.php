<?php
session_start();
 
$err="";
$conn=mysqli_connect("localhost","root","","form");
if (isset($_POST['update'])) {
	$new_pass=$_POST['new_pass'];
	$confirm_pass=$_POST['confirm_pass'];

	if ($new_pass!=$confirm_pass) {
		$err=true;
	}
	else{

	$sql="UPDATE `desc` SET `password`='$new_pass' 	WHERE `email`='$_SESSION[email]'";
    $qry=mysqli_query($conn,$sql);
    if ($qry) {
        header('location:login.php');

    }
}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
 		*{
 			margin: 0px;
 			padding: 0px;
 		}
  ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
  position: sticky;
  top: 0;
}

li {
  float: left;
  
  display: block;
  color: orange;
  text-align: center;
  padding: 14px ;
  font-size: 32px;
  text-decoration: none;
  margin-left: 50px;

}

ul li :hover {
  background-color: black;
}
.err{
	color: red;
}

 </style>
</head>
<body>
	  <ul>
     	<li><b><u><em>BALLISTIC LEARNING PVT LTD</em></u></b></li>
   
     </ul><br><br>
   <form method="post">
   	<h1><u>Generating Password</u></h1><br>
   	<?php
   if ($err) {?>
   	  <h3 style="color: red;font-size: 24px;"><u>Password did not match</u></h3>;
   <?php }
   	?>
   	 <table>
   	 	<tr>
   	 		<td><b>New - Password</b></td>
   	 		<td><input type="password" name="new_pass"></td>
   	 	</tr>

   	 	<tr>
   	 		<td><b>Confirm - Password</b></td>
   	 		<td><input type="password" name="confirm_pass"></td>
   	 	</tr>
   	 	<tr>
   	 		<TD></TD>
   	 		<TD><input type="submit" name="update" value="update"></TD>
   	 	</tr>
   	 </table>
   </form>
</body>
</html>