 <?php
session_start();
if (!$_SESSION['id']) {
    header("location:index.php");

} 
$conn=mysqli_connect("localhost","root","","form");
$sql="SELECT * FROM `desc` WHERE `id`='$_SESSION[id]'";
$qry=mysqli_query($conn,$sql);
if ($qry) {
  $data=mysqli_fetch_array($qry);
}

 ?>
 <!DOCTYPE html>
 <html>
 <head>
   <title></title>
   <style type="text/css">
     .container{
      text-align: center;
     }
     table{
     
      margin-left: 480px;
     }
   </style>
 </head>
 <body>
  
    
   <h1 align="center"><b><u>Welcome <?php echo $_SESSION['name'];?></u></b></h1>
   <a href="logout.php" style="float: right;"><button style="font-size: 24px;padding: 2px;">Logout</button></a> 
   <?php
   if ($_SESSION['role']==1) {?>
    <a href="admin.php" style="float: right;"><button style="font-size: 24px;padding: 2px;">Admin Use</button></a> 
  <?php }
   ?><br><br><br>
    <a href="email.php"><button style="float: right; padding: 1px;font-size: 32px;">Email</button></a>
    
   <br><br>
   <div class="container">
     <?php

  if ($data) {?>
  <img src="img/<?=$data['image']?>" style="height: 200px;width: 200px;">
    <table border="1">
      <tr>
         <td>Firstname</td>
         <td><?=$data['firstname']?></td>
      </tr>
      <tr>
        <td>Lastname</td>
        <td><?=$data['lastname']?></td>
      </tr>
      <tr>
        <td>Email</td>
        <td><?=$data['email']?></td>
      </tr>
      <tr>
        <td>Mobile</td>
        <td><?=$data['mobile']?></td>
      </tr>
      <tr>
        <td>Experience</td>
        <td><?=$data['experience']?></td>
      </tr>
      <tr>
        <td>Age</td>
        <td><?=$data['age']?></td>
      </tr>
      <tr>
        <td>D.O.B</td>
        <td><?=$data['dob']?></td>
      </tr>
      <tr>
        <td>Education</td>
        <td>
          <?php
         $edu=json_decode($data['education'],true);
           // echo "<pre>";
           //    print_r($edu);
             // die();

           foreach ($edu['from'] as $key => $value) { ?>
          
                    From =   <?=$edu['from'][$key]?><br>
                    To =     <?=$edu['to'][$key]?><br>
                    Course = <?=$edu['course'][$key]?><br>
                    College =<?=$edu['college'][$key]?><br>

        <?php  echo "<br>";} ?>


        </td>
      </tr>
      <tr>
        <td>Gender</td>
        <td><?=$data['gender']?></td>
      </tr>
      <tr>
        <td>Address</td>
        <td><?=$data['address']?></td>
      </tr>
       <tr>
        <td></td>
        <td><a href="user_edit.php?id=<?=$data['id']?>" style="font-size: 21px;"><B>Edit Your Credentials</B></a></td>
      </tr>
    </table>
<?php }
     ?>
   </div>
 </body>
 </html>