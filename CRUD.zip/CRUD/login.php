<?php
session_start();
if(!isset($_POST['flag']) || $_POST['flag'] != '1') {
$captcha=md5(rand());
$_SESSION['cap']=substr($captcha,0,6);

}
$show_captacha="";
$emailErr=$passwordErr="";
$email=$password="";

$conn=mysqli_connect("localhost","root","","form");

    if (isset($_POST['submit'])) {
    	// extract($_POST);
      if ($_POST['cap'] != $_SESSION['cap'] ) {
             $show_captacha=true;
      }
      else{

    	$email=$_POST['n1'];
    	$password=$_POST['n2'];
          
    if (empty($email)) {
    	$emailErr="Enter email address";
    }
    else{
    	$email=$_POST['n1'];
    }
    if (empty($password)) {
    	$passwordErr="Enter email address";
    }
    else{
    	$password=$_POST['n2'];
    }

    $sql="SELECT * FROM `desc` WHERE `email`='$email' && `password`='$password'";
    $qry=mysqli_query($conn,$sql);
    if ($qry) {
    	$data=mysqli_fetch_array($qry);
    	if ($data) {
        $_SESSION['role'] = $data['role'];
         $_SESSION['id'] = $data['id'];

    	$firstname=$data['firstname'];
      
    	$_SESSION['name']=$firstname;
    	$_SESSION['email']=$data['email'];
    	$_SESSION['password']=$data['password'];
    	header("location:welcome.php");
    }
    else{
    	echo '<script>  alert("either email or password is invalid");</script>';
    }
    }
}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
 		*{
 			margin: 0px;
 			padding: 0px;
 		}
  ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
  position: sticky;
  top: 0;
}

li {
  float: left;
  
  display: block;
  color: orange;
  text-align: center;
  padding: 14px ;
  font-size: 32px;
  text-decoration: none;
  margin-left: 50px;

}

ul li :hover {
  background-color: black;
}
.err{
	color: red;
}

 </style>
</head>
<body>
 <ul>
     	<li><b><u><em>BALLISTIC LEARNING PVT LTD</em></u></b></li>
   
     </ul><br><br>
     <?php
      if ($show_captacha) {?>
         <h2 style="color: red;font-size: 32px;"><b><u>Error:captcha does not match</u></b></h2>
     <?php }
     ?>
     <form method="post">
     	<h2><b><u><em>Login Form</em></u></b></h2><br>
     	<table>
     		<tr>
     			<td><b>Email<b></td>
     			<td><input type="text" name="n1" required="">
     				<span class="err">*<?php echo $emailErr; ?></span></td>
     		</tr>
     		<tr>
     			<td><b>Password<b></td>
     			<td><input type="password" name="n2" required="" id="pass">
     				<span class="err">*<?php echo $passwordErr; ?></span></td>
     		</tr>
     		<tr>
     			<td></td>
     			<td><input type="checkbox" name="check" onclick="fun()">
                 <small>Show password</small>
     			</td>
     		</tr>
     		<tr>
     			<td><b>Captcha<b></td>
     			<td><?php echo $_SESSION['cap'];?></td>
     		</tr>
     		<tr>
     			<td></td>
     			<td>
                    <input type="hidden" name="flag" value='1'>
                    <input type="captcha" name="cap"></td>
     		</tr>
     		<tr>
     		<td></td>
     			<td><input type="submit" name="submit">
     				<a href="registration.php">Kindly register before login</a></td>
            
     		</tr>
             <TR>
               <td></td>
               <td><a href="forget_password.php"><b>Forget password</b></a></td>
             </TR>
         
     	</table>
     </form>
      <script>
       function fun() {
         var a=document.getElementById('pass');
         if (a.type=="password") {
            a.type="text";
         }
         else{
            a.type="password";
         }
       }
      </script>
   
</body>
</html>